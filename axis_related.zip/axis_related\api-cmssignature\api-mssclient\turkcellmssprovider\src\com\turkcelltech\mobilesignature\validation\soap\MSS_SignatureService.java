/**
 * MSS_SignatureService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.turkcelltech.mobilesignature.validation.soap;

public interface MSS_SignatureService extends javax.xml.rpc.Service {
    public java.lang.String getMSS_SignatureAddress();

    public com.turkcelltech.mobilesignature.validation.soap.MSS_SignaturePortType getMSS_Signature() throws javax.xml.rpc.ServiceException;

    public com.turkcelltech.mobilesignature.validation.soap.MSS_SignaturePortType getMSS_Signature(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
