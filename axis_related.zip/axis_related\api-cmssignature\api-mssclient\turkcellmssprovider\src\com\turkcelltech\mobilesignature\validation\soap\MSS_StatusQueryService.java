/**
 * MSS_StatusQueryService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.turkcelltech.mobilesignature.validation.soap;

public interface MSS_StatusQueryService extends javax.xml.rpc.Service {
    public java.lang.String getMSS_StatusPortAddress();

    public com.turkcelltech.mobilesignature.validation.soap.MSS_StatusQueryPortType getMSS_StatusPort() throws javax.xml.rpc.ServiceException;

    public com.turkcelltech.mobilesignature.validation.soap.MSS_StatusQueryPortType getMSS_StatusPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
