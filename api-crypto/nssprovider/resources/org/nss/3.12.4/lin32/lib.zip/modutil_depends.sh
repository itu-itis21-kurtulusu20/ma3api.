#!/bin/sh
SCRIPT_LOCATION=$0
#if [ -x "$READLINK" ]; then
#  while [ -L "$SCRIPT_LOCATION" ]; do
#    SCRIPT_LOCATION=`"$READLINK" -e "$SCRIPT_LOCATION"`
#  done
#fi

#ESYA_LIB_PATH=`dirname "$SCRIPT_LOCATION"`
ESYA_LIB_PATH=$1
#\
LD_LIBRARY_PATH="$ESYA_LIB_PATH"
#\
echo $ESYA_LIB_PATH
echo $LD_LIBRARY_PATH
 
export LD_LIBRARY_PATH
eval ldd ./modutil
